<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>ChatBot</title>

	<meta property="og:title" content="Ma page web">
	<meta property="og:description" content="Je parle de mes passions">

	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

	<link rel="stylesheet" type="text/css" href="https://bootswatch.com/_vendor/bootstrap/dist/css/bootstrap.min.css" />

</head>
<body>

	<!-- menu -->

	<h1 style="text-align: center;">ChatBot</h1><br> <!-- le titre et je l'ai mis au center horizontalement -->

	<p>Bienvenue a ChatBot. Vous pouvez chatter avec notre petit chatbot. Programmé par Eren TURKOGLU. </p> <!-- un petit description -->

	<form method="post"> <!-- Voici le form on peut entrer le question et l'envoyer grace a la methode post -->
		<input type="text" class="form-control" id="inputDefault questiont" name="questiont">
		<button type="submit" class="btn btn-primary" id="envoyerbtn" onclick="btnfonc()">Envoyer</button><br>
		<b id="textbid"></b>	
	</form>

	<?php

	if($_POST){ // si il y a un ou plusieurs donnees qui est recu par post
		$textt = $_POST["questiont"]; //je prends la question

	if(strtolower($textt) == "bonjour"){ //je traite la question mais je le transforme en miniscule pour ne pas avoir de problemes avec les caracteres
		$resp = "Bonjour.";
	}else if(strtolower($textt) == "bonsoir"){//quelques petit reponse au petit questions
		$resp = "Bonsoir.";
	}else if(strtolower($textt) == "ça va?"){
		$resp = "Oui, merci.";
	}else if(str_contains($textt, "+")){ //la c est pour l addition. Si il y a le caractere + dans la question
		$nombres = explode("+", $textt); //je prends tous les nombres avant le plus et apres
		$total = 0; //un variable total pour faire l addition
		for ($i=0; $i < count($nombres); $i++) { //un boucle qui va tourner le nombre d element fois
			$total = $total + intval($nombres[$i]); //je prends le nombre je le transforme en int(variable nombre) et je l'ajoute a notre variable d addition
		}
		$resp = "Total : ".$total; //et je montre le resultat
	}else if(strtolower($textt) == "qui tu es?"){
		$resp = "Je suis un ChatBot programmé par Eren TURKOGLU.";
	}else{ //si le question nest pas celle que je traite je mais un petit erreur
		$resp = "Question incompréhensible.";
	}

	?>

	<div> <!-- Et ça c est pour montrer la question et le reponse -->
		<p>Question : <?php echo($textt); ?></p>
		<b>Reponse : <?php echo($resp); ?></b>
	</div>

	<?php

	}

	?>

</body>
</html>